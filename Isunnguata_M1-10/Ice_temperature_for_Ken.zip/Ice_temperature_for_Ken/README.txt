Temperature file format:
column 0: Depth below surface (m)
column 1: Temperature (degC)
